declare namespace App {
  interface Locals {
    token: string | null;
    level: string | null;
  }
}
