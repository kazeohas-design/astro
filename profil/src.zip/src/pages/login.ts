// import type { APIRoute } from "astro";

// const redirect = (location: string) =>
//   new Response(null, {
//     status: 303,
//     headers: { Location: location },
//   });

// const failureResponse = () => redirect("/login?error=1");

// export const POST: APIRoute = async ({ request, cookies }) => {
//   const formData = await request.formData().catch(() => null);
//   console.log(formData);
//   if (!formData) {
//     return failureResponse();
//   }
//   const username = formData.get("username");
//   const password = formData.get("password");

//   if (typeof username !== "string" || typeof password !== "string") {
//     return failureResponse();
//   }

//   // DEBUG: cek beneran keambil apa nggak
//   console.log("Login payload:", { username, password });

//   try {
//     const res = await fetch(import.meta.env.AUTH_BASE_URL + "/login", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify({ username, password }),
//     });

//     if (!res.ok) {
//       return failureResponse();
//     }

//     const data = await res.json();

//     if (data?.token) {
//       cookies.set("token", data.token, {
//         path: "/",
//         httpOnly: true,
//         secure: true,
//         sameSite: "strict",
//         maxAge: 60 * 60 * 24 * 7,
//       });
//     }
//   } catch {
//     return failureResponse();
//   }

//   return redirect("/dashboard");
// };

// src/pages/login.ts
import type { APIRoute } from "astro";

export const POST: APIRoute = async ({ request }) => {
  console.log("=== POST /login KEPAKE ===");

  const formData = await request.formData();
  const obj = Object.fromEntries(formData);
  console.log("FormData:", obj);

  return new Response("OK", {
    status: 200,
  });
};
