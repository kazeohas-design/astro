// import accordian from '../../../main/ui-components/accordian/code-ui-accordian.html'
// Call the function for multiple files
loadAndHighlightHtml("../../../main/ui-components/accordian/code-ui-accordian.html", "output1");
// loadAndHighlightHtml("ui-components/accordian/code-ui-accordian-flush.html", "output2");
